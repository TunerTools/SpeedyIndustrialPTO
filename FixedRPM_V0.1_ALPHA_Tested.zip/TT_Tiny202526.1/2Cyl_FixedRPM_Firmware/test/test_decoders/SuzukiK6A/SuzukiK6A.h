void testSuzukiK6A_setEndTeeth(void);
void testSuzukiK6A_getCrankAngle(void);
